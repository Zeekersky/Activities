import cv2
import numpy as np
import matplotlib.pyplot as plt

vidFILE = "v_BabyCrawling_g18_c05.avi"
vid = cv2.VideoCapture(vidFILE)

if not vid.isOpened():
    print("Video not found or can't open.")
else:
    print("Specify K: ")
    k = int(input())
    frame_no = 0
    
    while True:
        r, frame = vid.read()
        
        if (r == True):
            if frame_no % k == 0:
                # Rescale to 256x256
                ReqHeight, ReqWidth = 256, 256
                CurHeight, CurWidth, dim = frame.shape
                scaleFactorX = ReqWidth / CurWidth
                scaleFactorY = ReqHeight / CurHeight
                resizedFRAME = np.zeros((ReqHeight, ReqWidth, dim),dtype = np.uint8)
    
                for y in range(ReqHeight):
                    for x in range(ReqWidth):
                        NewX = int(x / scaleFactorX)
                        NewY = int(y / scaleFactorY)
                        resizedFRAME[y, x] = frame[NewY, NewX]
                
                cv2.imwrite(f"v_BabyCrawling_g18_c05/{frame_no}.jpg", frame)
                
            frame_no += 1
            
        else:
            break;
        