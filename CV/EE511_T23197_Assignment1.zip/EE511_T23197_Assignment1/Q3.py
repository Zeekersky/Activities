# -*- coding: utf-8 -*-
"""
Created on Sat Sep  2 23:33:09 2023

@author: Akash
"""

import numpy as np
import matplotlib.pyplot as plt
from numpy import load

data = load('mnist.npz')
list = data.files
for item in list:
    print(item)
    print(data[item])
    
# Q3. 1. represent each image in train/test datasets to a frequency histogram and save to comma separated values (CSV) files

bin_size = 256

# Creating train.csv

with open('train.csv', 'w') as csvFILE:
    csvFILE.write('Label, ' + ' ,'.join([f'bin{i}' for i in range(bin_size)]) + '\n')
    

i = 0
for mat in data['x_train']:
    
    hist = [0] * bin_size
    for row in mat:
        for val in row:
            hist[val] += 1
    
    with open('train.csv', 'a') as csvFILE:
        csvFILE.write(str(data['y_train'][i]) + ' ,' + ' ,'.join([f'{str(hist[j])}' for j in range(bin_size)]) + '\n')
    j = 0
    i += 1

# Creating test.csv
with open('test.csv', 'w') as csvFILE:
    csvFILE.write('Label, ' + ' ,'.join([f'bin{i}' for i in range(bin_size)]) + '\n')
    
    # print(csvFILE.closed)

i = 0
for mat in data['x_test']:
    
    hist = [0] * bin_size
    for row in mat:
        for val in row:
            hist[val] += 1
    
    with open('test.csv', 'a') as csvFILE:
        csvFILE.write(str(data['y_test'][i]) + ' ,' + ' ,'.join([f'{str(hist[j])}' for j in range(bin_size)]) + '\n')
    j = 0
    i += 1

csvFILE.close()

# Q3. 2. Normalize each feature to N(0,1) also apply the respective transformations to test data.

# Normalizing each feature
mean = np.zeros(data['x_train'][0].shape)
for mat in data['x_train']:
    mean += mat
mean /= len(data['x_train'])

standardDEV = np.zeros(data['x_train'][0].shape)
for mat in data['x_train']:
    standardDEV += ((mat - mean) ** 2)
standardDEV = np.sqrt(standardDEV/len(data['x_train']))


TransformIMGS = []
for mat in data['x_train']:
    TransformIMG = (mat - mean) / standardDEV
    TransformIMGS.append(TransformIMG)

# plt.imshow(data['x_train'][0], cmap = 'gray')
# plt.imshow(TransformIMGS[0], cmap = 'gray')
# print(data['y_train'][0])   

# apply respective transformation to test data
TransformIMGS_Test = []
for mat in data['x_test']:
    TransformIMG_Test = (mat - mean) / standardDEV
    TransformIMGS_Test.append(TransformIMG_Test)
    
# plt.imshow(data['x_test'][0], cmap = 'gray')
# plt.imshow(TransformIMGS_Test[0], cmap = 'gray')
# print(data['y_test'][0])

# Normalizing each feature
sample = len(data['x_train'])
features = len(data['x_train'][0])




    
    


