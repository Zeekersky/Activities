import cv2
import numpy as np
import matplotlib.pyplot as plt
import random as rd

# Q1.1. Load Image and Resize and GrayScale

img = cv2.imread('datasetIMAGE.jpg')

# Resize
ReqHeight, ReqWidth = 256, 256
CurHeight, CurWidth, dim = img.shape

X = ReqWidth / CurWidth
Y = ReqHeight / CurHeight

resizedIMG = np.zeros((ReqHeight, ReqWidth, dim),dtype = np.uint8)

for y in range(ReqHeight):
    for x in range(ReqWidth):
        resizedIMG[y, x] = img[int(y / Y), int(x / X)]
      

# GrayScale
grayIMG = np.zeros((ReqWidth, ReqHeight, dim), dtype = np.uint8)

for y in range(ReqHeight):
    for x in range(ReqHeight):
        pixR, pixG, pixB = resizedIMG[y, x]
        gray = int(0.299 * pixR + 0.587 * pixG + 0.114 * pixB)
        grayIMG[y, x] = gray

# Q1.2. Display both RGB and Gray image side-by-side using matplotlib

plt.figure(1)
plt.subplot(1,2,1)
plt.imshow(img[...,::-1])

plt.subplot(1,2,2)
plt.imshow(grayIMG)

# Q1.3. Save the Gray image

cv2.imwrite("gray-image.jpg", grayIMG)


# Q1.4. Flip the RGB Image horizontally and Display the original and flipped images side-by-side

flipIMG = np.zeros((CurHeight, CurWidth, dim),dtype = np.uint8)

for y in range(CurHeight):
    for x in range(CurWidth):
        flipIMG[y,x] = img[y, (CurWidth - x - 1)]
        
        
plt.figure(2)
plt.subplot(1,2,1)
plt.imshow(img[...,::-1])

plt.subplot(1,2,2)
plt.imshow(flipIMG[...,::-1])
        
    

# Flip the RGB Image vertically and Display the original and flipped images side-by-side


flipIMG2 = np.zeros((CurHeight, CurWidth, dim),dtype = np.uint8)
for y in range(CurHeight):
    for x in range(CurWidth):
        flipIMG2[y, x] = img[(CurHeight - y - 1), x]
        
plt.figure(3)
plt.subplot(1,2,1)
plt.imshow(img[...,::-1])

plt.subplot(1,2,2)
plt.imshow(flipIMG2[...,::-1])

# Q1.5. Perform random crops of 128x128 and rescale it to 256x256. Display the center point and a rectangle of 128x128 on the RGB image and cropped & scaled image side by side

# random crops of 128x128
ReqRes = (128, 128)
randX = rd.randint(0, CurWidth - ReqRes[0])
randY = rd.randint(0, CurHeight - ReqRes[1])

cropIMG = img[randY: randY + ReqRes[0], randX: randX + ReqRes[1]]

# rescale it to 256x256
ReqHeight, ReqWidth = 256, 256
CurHeight, CurWidth, dim = cropIMG.shape

scaleX = ReqWidth / CurWidth
scaleY = ReqHeight / CurHeight

resizedIMG1 = np.zeros((ReqHeight, ReqWidth, dim),dtype = np.uint8)

for y in range(ReqHeight):
    for x in range(ReqWidth):
        NewX = int(x / scaleX)
        NewY = int(y / scaleY)
        resizedIMG1[y, x] = cropIMG[NewY, NewX]
        

# Display the center point and a rectangle of 128x128 on the RGB image and cropped & scaled image side by side.

centerX = ReqRes[1] // 2
centerY = ReqRes[0] // 2

rectX1 = 0
rectX2 = ReqRes[1]

rectY1 = 0
rectY2 = ReqRes[0]

img1 = np.zeros(img.shape,dtype = np.uint8)
img1[...,::-1] = img[...,::-1]

img1[randY + centerY, randX + centerX] = [0, 0, 255]

for y in range(rectY1, rectY2):
    img1[randY + y, randX]= [0, 0, 255]
    img1[randY + y, randX + ReqRes[0]]= [0, 0, 255]

        
for x in range(rectX1, rectX2):
    img1[randY, randX + x]= [0, 0, 255]
    img1[randY + ReqRes[1], randX + x]= [0, 0, 255]
        
    
plt.figure(4)
plt.subplot(2,2,1)
plt.imshow(img1[...,::-1])

plt.subplot(2,2,3)
plt.imshow(cropIMG[...,::-1])

plt.subplot(2,2,4)
plt.imshow(resizedIMG1[...,::-1])






        












